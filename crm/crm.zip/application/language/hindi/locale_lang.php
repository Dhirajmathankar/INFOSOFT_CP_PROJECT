<?php
/*
 * Hindi language
 */
        // title
        $lang['welcome_message'] = 'ginfo में आपका स्वागत है'; 


$lang['add_employee'] = 'कर्मचारी जोड़ें';
$lang['employee_listing'] = 'कर्मचारी की सूची';
$lang['welcome_message'] = 'Welcome To our Site message';
$lang['welcome_message'] = 'Welcome To our Site message';



$lang['msg']= 'कोडइग्निटार में अंतर्राष्ट्रीयकरण उदाहरण';
$lang['welcome']= 'हिंदी भाषा में आपका स्वागत है';
$lang['chooseLang']= 'अपनी भाषा चुनिए';
$lang['copyright']= 'सत्त्वाधिकार';
$lang['year']= '२०१९';


?>
