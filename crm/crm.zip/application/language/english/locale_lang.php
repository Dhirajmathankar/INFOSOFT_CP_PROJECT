<?php
/*
 * English language
 */
 
$lang['welcome_message'] = 'Welcome To our Site message';

$lang['add_employee'] = 'Add Employee';
$lang['employee_listing'] = 'Employee listing';
$lang['welcome_message'] = 'Welcome To our Site message';
$lang['welcome_message'] = 'Welcome To our Site message';




$lang['msg']= 'Internationalization Example in Codeigniter';
$lang['welcome']= 'Welcome to English Language';
$lang['chooseLang']= 'Choose your language';
$lang['copyright']= 'Copyright';
$lang['year']= '2019';
        
?>